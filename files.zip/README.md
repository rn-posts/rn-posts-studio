# AlvoreSer Posts Studio

Painel web para criação, aprovação e publicação automática de posts no Instagram.

## Stack
- **React + Vite** — frontend
- **Firebase Firestore** — banco de dados / histórico em tempo real
- **Netlify Functions** — backend serverless
- **Python + Pillow** — geração de cards (sem custo de IA)
- **Cloudinary** — armazenamento de imagens
- **Make (webhook)** — publicação no Instagram

---

## Estrutura

```
AlvoreSer_Posts_Panel/
├── src/
│   ├── App.jsx
│   ├── firebase.js
│   ├── styles/global.css
│   └── components/
│       ├── Sidebar.jsx
│       ├── PostQueue.jsx     ← fila com aprovação visual
│       ├── PostEditor.jsx    ← criação/edição + geração de imagem + IA
│       └── History.jsx       ← histórico filtrado
├── netlify/
│   └── functions/
│       ├── gerar-card.js     ← chama Python → Cloudinary
│       └── gerar-legenda.js  ← Gemini / OpenAI / Claude
├── scripts/
│   ├── gerar_card.py         ← gera card 1080x1080 com Pillow
│   └── fonts/                ← coloque as fontes .ttf aqui
├── .env.example
└── netlify.toml
```

---

## Setup rápido

### 1. Instalar dependências
```bash
npm install
pip install pillow cloudinary
```

### 2. Fontes (identidade visual)
Baixe do Google Fonts e coloque em `scripts/fonts/`:
- `CormorantGaramond-SemiBold.ttf`
- `DMSans-Regular.ttf`
- `DMSans-Medium.ttf`

### 3. Variáveis de ambiente
Copie `.env.example` para `.env` e preencha:
- Firebase (do console do projeto — mesmo do prontuário ou um novo)
- Cloudinary (já tem as chaves)
- Make webhook URL
- Chave da IA que preferir usar

### 4. Rodar local
```bash
netlify dev
```
Acesse: http://localhost:8888

### 5. Deploy
```bash
# Teste tudo local antes!
netlify deploy --prod
```

---

## Fluxo de um post

```
Editor → [Gerar Card] → Python gera 1080x1080 → sobe Cloudinary → preview
       → [Gerar Legenda IA] → Gemini/OpenAI/Claude → texto editável
       → Salvar → Firestore (status: pendente ou aprovado)
       → [Aprovar] → status: aprovado
       → [Publicar] → webhook Make → Instagram
```

---

## Trocar de IA

No `.env`, mude apenas:
```
AI_PROVIDER=openai   # ou gemini, ou claude
```
Nenhum código precisa ser alterado.

---

## Identidade visual

As cores e fontes estão em `scripts/gerar_card.py` nas constantes do topo.
Para ajustar, edite apenas essa seção — o resto do código não muda.

```python
VERDE_ESCURO  = (45,  80,  22)
VERDE_MEDIO   = (74,  124, 47)
CREME         = (245, 240, 232)
# ...
```
